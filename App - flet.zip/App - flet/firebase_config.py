import firebase_admin
from firebase_admin import credentials, storage, firestore
import datetime
# Carga las credenciales desde el archivo JSON
cred = credentials.Certificate("firebaseConfig.json")  # Cambia la ruta si es necesario
firebase_admin.initialize_app(cred, {
    "storageBucket": "eyesaviors.appspot.com"  # Cambia por tu bucket de Firebase
})

# Inicializa Firebase Storage y Firestore
bucket = storage.bucket()
db = firestore.client()

# Exporta las referencias para usarlas en otros archivos
def get_bucket():
    return bucket

def get_firestore():
    return db

def obtener_url_archivo(bucket, archivo_nombre):
    try:
        blob = bucket.blob(f"BRAILLE/{archivo_nombre}")
        # Generar una URL firmada (válida por tiempo limitado)
        url = blob.generate_signed_url(expiration=datetime.timedelta(hours=1))
        print(f"URL del archivo: {url}")
        return url
    except Exception as e:
        print(f"Error al obtener la URL del archivo: {e}")
        return None

