import flet as ft

BG_COLOR = "#4c5f92"  # Color de fondo por defecto

def settings_page(page: ft.Page):
    page.title = "Settings"
    page.clean()

    # Botón de Volver
    def back_click(e):
        page.go("/")

    back_button = ft.IconButton(
        icon=ft.icons.ARROW_BACK,
        tooltip="Back",
        icon_size=40,
        on_click=back_click,
    ) 
    
    # Cambiar contraste
    def toggle_contrast(e):
        global BG_COLOR
        BG_COLOR = "#000000" if BG_COLOR != "#000000" else "#4c5f92"
        for view in page.views:
            view.bgcolor = BG_COLOR
        page.session.set("bg_color", BG_COLOR)
        page.update()

    # Aumentar tamaño de texto
    def increase_text_size(e):
        current_size = page.session.get("text_size") or 12
        if current_size < 30:  # Ponemos un límite superior (por ejemplo, 30)
            page.session.set("text_size", current_size + 2)
            page.update()

    # Disminuir tamaño de texto
    def decrease_text_size(e):
        current_size = page.session.get("text_size") or 12
        if current_size > 8:  # Ponemos un límite inferior (por ejemplo, 8)
            page.session.set("text_size", current_size - 2)
            page.update()

    contrast_button = ft.ElevatedButton(
        "High Contrast Mode",
        on_click=toggle_contrast,
        width=200,
    )

    increase_text_button = ft.ElevatedButton(
        "Increase Text Size",
        on_click=increase_text_size,
        width=200,
    )

    decrease_text_button = ft.ElevatedButton(
        "Decrease Text Size",
        on_click=decrease_text_size,
        width=200,
    )

    audio_url="welcome1.mp3"  # Cambia esto por la ruta de tu archivo de audio
    audio1 = ft.Audio(
        src=audio_url,
        autoplay=False, 
    )
    
    page.overlay.append(audio1)
    def open_audio(e):
        audio1.play()
    # Botón de Audio
    audio_button = ft.IconButton(
        icon=ft.icons.SPATIAL_AUDIO_OFF_SHARP,
        tooltip="Audio",
        icon_size=40,
        on_click=open_audio,
    )

    # <-- AQUÍ ambos botones van en el mismo Row y Container -->
    top_buttons = ft.Container(
        content=ft.Row(
            controls=[
                back_button,
                ft.Container(expand=True),  # Para separar los botones a extremos
                audio_button,
            ],
            vertical_alignment=ft.CrossAxisAlignment.START,
        ),
        padding=ft.padding.only(left=10, right=10, top=10),
    )
    # Contenedor principal para los controles
    main_container = ft.Container(
        content=ft.Column(
            controls=[
                ft.Text("Settings", size=24),
                contrast_button,
                ft.Text("Adjust text size:", size=16),
                increase_text_button,
                decrease_text_button,
            ],
            spacing=20,
            alignment=ft.MainAxisAlignment.START,
            
        ),
        alignment=ft.alignment.top_center,
        expand=True,
        
    )


    
    # Devuelve la lista de controles, incluyendo el contenedor de la parte superior
    return [top_buttons, main_container]



