import flet as ft
from app import home_page
from explore import explore_page
from upload import upload_page
from settings import settings_page, BG_COLOR

def main(page: ft.Page):
    page.title = "Mi App"
    page.window_width = 400
    page.window_height = 800
    page.window_resizable = False

    # Configura la navegación
    def route_change(e):
        page.views.clear()  # Limpiar vistas (no controles)
        global BG_COLOR
        stored_color = page.session.get("bg_color")
        if stored_color:
            BG_COLOR = stored_color
        if page.route == "/":
            # Call home_page and pass its returned controls to the View
            page.views.append(ft.View("/", controls=home_page(page), bgcolor=BG_COLOR))
        elif page.route == "/explore":
            page.views.append(ft.View("/explore", controls=explore_page(page), bgcolor=BG_COLOR))
        elif page.route == "/upload":
            page.views.append(ft.View("/upload", controls=upload_page(page), bgcolor=BG_COLOR))
        elif page.route == "/settings":
            page.views.append(ft.View("/settings", controls=settings_page(page), bgcolor=BG_COLOR))
        else:
            page.views.append(ft.View("/404", [ft.Text("Página no encontrada")]))

        page.update()  # Asegúrate de actualizar la página

    page.on_route_change = route_change
    page.go("/")  # Inicia en la página principal

ft.app(target=main)

