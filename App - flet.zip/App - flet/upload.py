import flet as ft
import time
from firebase_config import get_bucket, obtener_url_archivo
from procesamiento import procesar_desde_url

def upload_page(page: ft.Page):
    page.title = "Processing"
    page.vertical_alignment = ft.MainAxisAlignment.CENTER
    page.horizontal_alignment = ft.CrossAxisAlignment.CENTER

    # Recuperar el nombre del archivo desde el almacenamiento local
    archivo_nombre = page.client_storage.get("uploaded_file") or "Archivo desconocido"

    bucket = get_bucket()
    archivo_url = obtener_url_archivo(bucket, archivo_nombre)
    extension = archivo_nombre.split('.')[-1].lower()
    print(extension)

    # Contenido principal
    if archivo_url:
        # Procesar el archivo directamente desde la URL
        text, braille, angulos = procesar_desde_url(archivo_url, archivo_nombre)
        print("Cantidad de angulos", len(angulos))

        if text and braille and angulos:
            content = ft.Column(
                controls=[
                    ft.Text("File processed successfully.", size=24, weight=ft.FontWeight.BOLD),
                    ft.Text(f"File Name: {archivo_nombre}", size=18),
                    # ft.Text(f"Texto detectado: {text}"),
                    # ft.Text(f"Texto en Braille: {braille}"),
                    # ft.Text(f"Ángulos enviados al ESP32: {angulos}"),
                    ft.Text("Translating to Braille...", size=18),
                ],
                alignment=ft.MainAxisAlignment.CENTER,
                horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                spacing=20,
            )
        else:
            content = ft.Text("Error processing file.", color="red")
    else:
        content = ft.Text("Error obtaining file's URL", color="red")

    # Contenedor principal
    main_container = ft.Container(
        content=content,
        alignment=ft.alignment.center,  # Centrar el contenido
        expand=True,  # Expande el contenedor para ocupar toda la página
    )

    return [main_container]