import flet as ft
from firebase_config import get_bucket

# Inicializamos el bucket de Firebase
storage = get_bucket()

def explore_page(page: ft.Page):
    page.title = "Upload File"
    page.vertical_alignment = ft.MainAxisAlignment.CENTER
    page.horizontal_alignment = ft.CrossAxisAlignment.CENTER

    # Obtener tamaño de texto actual desde sesión
    text_size = page.session.get("text_size")
    if text_size is None:
        text_size = 12  # tamaño por defecto si no existe

    # Texto de estado
    status_text = ft.Text("Waiting for file", size=text_size+2)  # Ahora con tamaño dinámico

    # Función para manejar la carga de archivos a Firebase Storage
    def cargar_archivo(e):
        if file_picker.result and file_picker.result.files:
            archivo = file_picker.result.files[0]  # Tomamos el primer archivo
            archivo_nombre = archivo.name

            try:
                # Subimos el archivo a Firebase Storage
                blob = storage.blob(f"BRAILLE/{archivo_nombre}")
                with open(archivo.path, "rb") as f:
                    blob.upload_from_file(f)

                status_text.value = f"File '{archivo_nombre}' uploaded successfully."
                page.client_storage.set("uploaded_file", archivo_nombre)
                page.go("/upload")
            except Exception as ex:
                status_text.value = f"Error al subir el archivo: {str(ex)}"
        else:
            status_text.value = "No se seleccionó ningún archivo."
        page.update()

    # Crear el selector de archivos
    file_picker = ft.FilePicker(on_result=cargar_archivo)

    # Agregar el FilePicker como overlay
    page.overlay.append(file_picker)

    # Botón para abrir el FilePicker
    seleccionar_archivo_btn = ft.ElevatedButton(
        "Choose File",
        on_click=lambda _: file_picker.pick_files(allow_multiple=False),
        bgcolor="#e61548",
        color="#FFFFFF",
        style=ft.ButtonStyle(
            padding={"top": 12, "bottom": 12, "left": 24, "right": 24},
            shape=ft.RoundedRectangleBorder(radius=24),
            text_style=ft.TextStyle(size=text_size+2),  # Tamaño de texto dinámico para el botón también
        )
    )

    

    # Botón de Settings
    def open_settings(e):
        page.go("/settings")

    settings_button = ft.IconButton(
        icon=ft.icons.SETTINGS,
        tooltip="Settings",
        on_click=open_settings,
        icon_size=40,
    )

    audio_url="welcome1.mp3"  # Cambia esto por la ruta de tu archivo de audio
    audio1 = ft.Audio(
        src=audio_url,
        autoplay=False, 
    )
    
    page.overlay.append(audio1)
    def open_audio(e):
        audio1.play()
    # Botón de Audio
    audio_button = ft.IconButton(
        icon=ft.icons.SPATIAL_AUDIO_OFF_SHARP,
        tooltip="Audio",
        icon_size=40,
        on_click=open_audio,
    )

    # <-- AQUÍ ambos botones van en el mismo Row y Container -->
    top_buttons = ft.Container(
        content=ft.Row(
            controls=[
                audio_button,
                ft.Container(expand=True),  # Para separar los botones a extremos
                settings_button,
            ],
            vertical_alignment=ft.CrossAxisAlignment.START,
        ),
        padding=ft.padding.only(left=10, right=10, top=10),
    )

    main_container = ft.Container(
        content=ft.Column(
            controls=[
                ft.Text("Select a file to translate", size=text_size + 12),  # Ahora depende del text_size
                seleccionar_archivo_btn,
                status_text,
            ],
            alignment=ft.MainAxisAlignment.CENTER,
            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
            spacing=20,
        ),
        alignment=ft.alignment.center,
        expand=True,
    )

    return [top_buttons,main_container]
