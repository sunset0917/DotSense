import flet as ft
import os
def home_page(page: ft.Page):
    page.title = "Home"
    page.padding = 16

    # Obtener el tamaño de texto actualizado desde la sesión
    stored_text_size = page.session.get("text_size") or 12

    # Títulos
    title = ft.Text("DOT SENSE", size=stored_text_size + 20, weight="bold", color="#FFFFFF")
    subtitle = ft.Text("Text to braille translator", size=stored_text_size + 6, color="#FFFFFF")

    # Botón de Start
    def on_button_click(e):
        page.go("/explore")

    button = ft.ElevatedButton(
        text="Start",
        bgcolor="#e61548",
        color="#FFFFFF",
        on_click=on_button_click,
        style=ft.ButtonStyle(
            padding={"top": 12, "bottom": 12, "left": 24, "right": 24},
            shape=ft.RoundedRectangleBorder(radius=24),
            text_style=ft.TextStyle(size=stored_text_size + 2),
        )
    )

    # Botón de Settings
    def open_settings(e):
        page.go("/settings")

    settings_button = ft.IconButton(
        icon=ft.icons.SETTINGS,
        tooltip="Settings",
        on_click=open_settings,
        icon_size=40,
    )

    audio_url="welcome1.mp3"  # Cambia esto por la ruta de tu archivo de audio
    audio1 = ft.Audio(
        src=audio_url,
        autoplay=False, 
    )
    
    page.overlay.append(audio1)
    def open_audio(e):
        audio1.play()
    # Botón de Audio
    audio_button = ft.IconButton(
        icon=ft.icons.SPATIAL_AUDIO_OFF_SHARP,
        tooltip="Audio",
        icon_size=40,
        on_click=open_audio,
    )

    # <-- AQUÍ ambos botones van en el mismo Row y Container -->
    top_buttons = ft.Container(
        content=ft.Row(
            controls=[
                audio_button,
                ft.Container(expand=True),  # Para separar los botones a extremos
                settings_button,
            ],
            vertical_alignment=ft.CrossAxisAlignment.START,
        ),
        padding=ft.padding.only(left=10, right=10, top=10),
    )

    main_container = ft.Container(
        content=ft.Column(
            controls=[title, subtitle, button],
            alignment=ft.MainAxisAlignment.CENTER,
            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
            spacing=32,
        ),
        alignment=ft.alignment.center,
        expand=True,
    )

    return [top_buttons, main_container]







