from difflib import SequenceMatcher

def similar(a, b):
    return SequenceMatcher(None, a, b).ratio()

texto_original = "Hoy hace mucho frío. Es invierno y todas las calles están cubiertas de nieve. Dentro de poco vendrá la primavera. La semana pasada estuvo de lluvia y tormenta. Incluso un rayo cayó encima de la campana de la catedral, pero no ocurrió nada. Tenemos suerte, pues la previsión del tiempo para mañana es muy buena. A ver si tengo suerte y veo algún arcoíris. "
texto_traducido_imagen = "Hoy hace miicho frio. Es invierno y-todas las.calles estan cubiertas de nieve. Dentro de poco vendra la primavera. La semana pasada estuvo de lluvia y tormenta. Incluso un rayo cay6é encima de la campana de la €atedral, pero no ocurrié nada. Tenemos suerte, pues la previsién del tiempo para mafiana es muy buena..A-ver si tengo suerte y veo algun arcoiris."
text_traducido_pdf="Hoy hace mucho frío. Es invierno y todas las calles están cubiertas de nieve. Dentro de poco vendrá la primavera. La semana pasada estuvo de lluvia y tormenta. Incluso un rayo cayó encima de la campana de la catedral, pero no ocurrió nada. Tenemos suerte, pues la previsión del tiempo para mañana es muy buena. A ver si tengo suerte y veo algún arcoíris."
text_traducido_pdf_imagen="Hoy hace mucho frio. Es invierno y todas las calles estan cubiertas de nieve. Dentro de poco vendrd la primavera. La semana pasada estuvo de Iluvia y tormenta. Incluso un rayo cayéd encima de Ja campana de Ia catedral, pero no ocurrié nada. Tenemos suerte, pues la prevision del tiempo para mafiana es muy buena, A ver si tengo suerte y veo algun arcolrls."

precision1 = similar(texto_original, texto_traducido_imagen)
precision2 = similar(texto_original, text_traducido_pdf)
precision3 = similar(texto_original, text_traducido_pdf_imagen)
print(f"Precisión de la traducción por imagen: {precision1 * 100:.2f}%")
print(f"Precisión de la traducción por el pdf solo: {precision2 * 100:.2f}%")
print(f"Precisión de la traducción por el pdf e imagen: {precision3 * 100:.2f}%")